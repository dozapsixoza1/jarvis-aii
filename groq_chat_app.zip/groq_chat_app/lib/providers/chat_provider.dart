import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/chat_message.dart';
import '../models/chat_session.dart';
import '../services/groq_service.dart';
import '../services/storage_service.dart';

class ChatProvider extends ChangeNotifier {
  final GroqService _groq = GroqService();
  final StorageService _storage = StorageService();
  final _uuid = const Uuid();

  List<ChatSession> sessions = [];
  ChatSession? currentSession;
  bool isLoading = false;
  String? error;

  // Настройки
  String apiKey = '';
  String selectedModel = 'llama-3.3-70b-versatile';
  String systemPrompt =
      'Ты полезный и дружелюбный AI-ассистент. Отвечай на русском языке.';
  double temperature = 0.7;
  bool useStreaming = true;

  Future<void> init() async {
    final settings = await _storage.loadSettings();
    apiKey = settings['apiKey'] ?? '';
    selectedModel = settings['model'] ?? 'llama-3.3-70b-versatile';
    systemPrompt = settings['systemPrompt'] ?? systemPrompt;
    temperature = (settings['temperature'] as num?)?.toDouble() ?? 0.7;
    useStreaming = settings['useStreaming'] ?? true;

    sessions = await _storage.loadSessions();
    if (sessions.isNotEmpty) {
      currentSession = sessions.first;
    } else {
      createNewSession();
    }
    notifyListeners();
  }

  Future<void> saveSettings() async {
    await _storage.saveSettings({
      'apiKey': apiKey,
      'model': selectedModel,
      'systemPrompt': systemPrompt,
      'temperature': temperature,
      'useStreaming': useStreaming,
    });
  }

  void createNewSession() {
    final session = ChatSession(
      id: _uuid.v4(),
      title: 'Новый чат',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      messages: [],
    );
    sessions.insert(0, session);
    currentSession = session;
    _saveSessions();
    notifyListeners();
  }

  void selectSession(ChatSession session) {
    currentSession = session;
    notifyListeners();
  }

  Future<void> deleteSession(String id) async {
    sessions.removeWhere((s) => s.id == id);
    if (currentSession?.id == id) {
      if (sessions.isNotEmpty) {
        currentSession = sessions.first;
      } else {
        createNewSession();
      }
    }
    await _saveSessions();
    notifyListeners();
  }

  Future<void> _saveSessions() async {
    await _storage.saveSessions(sessions);
  }

  Future<void> sendMessage(String text) async {
    if (text.trim().isEmpty || isLoading || currentSession == null) return;

    final userMsg = ChatMessage(
      id: _uuid.v4(),
      text: text.trim(),
      isUser: true,
      timestamp: DateTime.now(),
    );

    currentSession!.messages.add(userMsg);

    // Автоназвание чата
    if (currentSession!.messages.length == 1) {
      currentSession!.title =
          text.length > 30 ? '${text.substring(0, 30)}...' : text;
    }

    currentSession!.updatedAt = DateTime.now();
    isLoading = true;
    error = null;
    notifyListeners();

    // Готовим историю для API
    final history = <Map<String, String>>[
      {'role': 'system', 'content': systemPrompt},
      ...currentSession!.messages
          .where((m) => !m.isError)
          .map((m) => {
                'role': m.isUser ? 'user' : 'assistant',
                'content': m.text,
              }),
    ];

    try {
      if (useStreaming) {
        // Стриминг
        final botMsgId = _uuid.v4();
        currentSession!.messages.add(ChatMessage(
          id: botMsgId,
          text: '',
          isUser: false,
          timestamp: DateTime.now(),
        ));
        notifyListeners();

        String full = '';
        await for (final chunk in _groq.sendMessageStream(
          apiKey: apiKey,
          messages: history,
          model: selectedModel,
          temperature: temperature,
        )) {
          full += chunk;
          final idx = currentSession!.messages
              .indexWhere((m) => m.id == botMsgId);
          if (idx != -1) {
            currentSession!.messages[idx] = ChatMessage(
              id: botMsgId,
              text: full,
              isUser: false,
              timestamp: DateTime.now(),
            );
            notifyListeners();
          }
        }
      } else {
        // Обычный ответ
        final reply = await _groq.sendMessage(
          apiKey: apiKey,
          messages: history,
          model: selectedModel,
          temperature: temperature,
        );
        currentSession!.messages.add(ChatMessage(
          id: _uuid.v4(),
          text: reply,
          isUser: false,
          timestamp: DateTime.now(),
        ));
      }
    } catch (e) {
      error = e.toString();
      currentSession!.messages.add(ChatMessage(
        id: _uuid.v4(),
        text: 'Ошибка: $e',
        isUser: false,
        timestamp: DateTime.now(),
        isError: true,
      ));
    } finally {
      isLoading = false;
      currentSession!.updatedAt = DateTime.now();
      // Перемещаем текущий чат в начало
      sessions.removeWhere((s) => s.id == currentSession!.id);
      sessions.insert(0, currentSession!);
      await _saveSessions();
      notifyListeners();
    }
  }

  void clearCurrentChat() {
    if (currentSession == null) return;
    currentSession!.messages.clear();
    currentSession!.title = 'Новый чат';
    currentSession!.updatedAt = DateTime.now();
    _saveSessions();
    notifyListeners();
  }
}
