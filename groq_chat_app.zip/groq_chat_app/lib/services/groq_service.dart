import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class GroqService {
  static const String baseUrl = 'https://api.groq.com/openai/v1/chat/completions';

  // Популярные модели Groq (можно добавлять новые)
  static const Map<String, String> availableModels = {
    'llama-3.3-70b-versatile': 'Llama 3.3 70B (лучшая)',
    'llama-3.1-8b-instant': 'Llama 3.1 8B (быстрая)',
    'llama-3.1-70b-versatile': 'Llama 3.1 70B',
    'gemma2-9b-it': 'Gemma 2 9B',
    'mixtral-8x7b-32768': 'Mixtral 8x7B',
  };

  Future<String> sendMessage({
    required String apiKey,
    required List<Map<String, String>> messages,
    required String model,
    double temperature = 0.7,
    int maxTokens = 2048,
  }) async {
    if (apiKey.isEmpty) {
      throw Exception('API Key не указан. Зайди в Настройки и вставь ключ.');
    }

    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'model': model,
        'messages': messages,
        'temperature': temperature,
        'max_tokens': maxTokens,
        'stream': false,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['choices'][0]['message']['content'] as String;
    } else {
      final errorBody = utf8.decode(response.bodyBytes);
      throw Exception('Ошибка ${response.statusCode}: $errorBody');
    }
  }

  /// Стриминг ответа — текст появляется по частям
  Stream<String> sendMessageStream({
    required String apiKey,
    required List<Map<String, String>> messages,
    required String model,
    double temperature = 0.7,
    int maxTokens = 2048,
  }) async* {
    if (apiKey.isEmpty) {
      throw Exception('API Key не указан. Зайди в Настройки и вставь ключ.');
    }

    final request = http.Request('POST', Uri.parse(baseUrl));
    request.headers.addAll({
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json',
    });

    request.body = jsonEncode({
      'model': model,
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
      'stream': true,
    });

    final response = await request.send();

    if (response.statusCode != 200) {
      final body = await response.stream.bytesToString();
      throw Exception('Ошибка стриминга ${response.statusCode}: $body');
    }

    await for (final chunk in response.stream.transform(utf8.decoder)) {
      final lines = chunk.split('\n');
      for (final line in lines) {
        if (line.startsWith('data: ') && !line.contains('[DONE]')) {
          try {
            final json = jsonDecode(line.substring(6));
            final content = json['choices']?[0]?['delta']?['content'];
            if (content != null && content is String) {
              yield content;
            }
          } catch (_) {
            // игнорируем битые чанки
          }
        }
      }
    }
  }
}
