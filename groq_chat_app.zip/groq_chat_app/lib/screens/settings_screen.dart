import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/chat_provider.dart';
import '../services/groq_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _apiKeyController;
  late TextEditingController _systemPromptController;
  late String _selectedModel;
  late double _temperature;
  late bool _useStreaming;

  @override
  void initState() {
    super.initState();
    final provider = context.read<ChatProvider>();
    _apiKeyController = TextEditingController(text: provider.apiKey);
    _systemPromptController = TextEditingController(text: provider.systemPrompt);
    _selectedModel = provider.selectedModel;
    _temperature = provider.temperature;
    _useStreaming = provider.useStreaming;
  }

  @override
  void dispose() {
    _apiKeyController.dispose();
    _systemPromptController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final provider = context.read<ChatProvider>();
    provider.apiKey = _apiKeyController.text.trim();
    provider.systemPrompt = _systemPromptController.text.trim();
    provider.selectedModel = _selectedModel;
    provider.temperature = _temperature;
    provider.useStreaming = _useStreaming;

    // Обновляем ключ в сервисе (для простоты)
    // В реальном проекте лучше передавать ключ в каждый запрос
    await provider.saveSettings();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Настройки сохранены'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: const Text('Настройки'),
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text(
              'Сохранить',
              style: TextStyle(color: Colors.deepPurpleAccent, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionTitle('API Key'),
          TextField(
            controller: _apiKeyController,
            obscureText: true,
            style: const TextStyle(color: Colors.white),
            decoration: _inputDecoration('Вставь свой Groq API Key'),
          ),
          const SizedBox(height: 8),
          Text(
            'Ключ можно взять на console.groq.com',
            style: TextStyle(color: Colors.grey[600], fontSize: 12),
          ),

          const SizedBox(height: 28),
          _sectionTitle('Модель'),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedModel,
                isExpanded: true,
                dropdownColor: const Color(0xFF1E1E1E),
                style: const TextStyle(color: Colors.white),
                items: GroqService.availableModels.entries.map((e) {
                  return DropdownMenuItem(
                    value: e.key,
                    child: Text(e.value),
                  );
                }).toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _selectedModel = v);
                },
              ),
            ),
          ),

          const SizedBox(height: 28),
          _sectionTitle('Системный промпт'),
          TextField(
            controller: _systemPromptController,
            maxLines: 4,
            style: const TextStyle(color: Colors.white),
            decoration: _inputDecoration('Инструкция для нейросети...'),
          ),

          const SizedBox(height: 28),
          _sectionTitle('Temperature: ${_temperature.toStringAsFixed(1)}'),
          Slider(
            value: _temperature,
            min: 0.0,
            max: 1.5,
            divisions: 15,
            activeColor: Colors.deepPurpleAccent,
            label: _temperature.toStringAsFixed(1),
            onChanged: (v) => setState(() => _temperature = v),
          ),
          Text(
            'Меньше = точнее и суше, больше = креативнее',
            style: TextStyle(color: Colors.grey[600], fontSize: 12),
          ),

          const SizedBox(height: 28),
          SwitchListTile(
            title: const Text('Стриминг ответов', style: TextStyle(color: Colors.white)),
            subtitle: Text(
              'Текст появляется по частям',
              style: TextStyle(color: Colors.grey[500], fontSize: 13),
            ),
            value: _useStreaming,
            activeColor: Colors.deepPurpleAccent,
            onChanged: (v) => setState(() => _useStreaming = v),
          ),

          const SizedBox(height: 40),
          OutlinedButton.icon(
            onPressed: () {
              context.read<ChatProvider>().clearCurrentChat();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Текущий чат очищен')),
              );
            },
            icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            label: const Text('Очистить текущий чат', style: TextStyle(color: Colors.redAccent)),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Colors.redAccent),
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.grey[600]),
      filled: true,
      fillColor: const Color(0xFF1E1E1E),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.all(14),
    );
  }
}
